from django.contrib import admin
from phone_app.models import Phones, Reviews

# Register your models here.
admin.site.register(Phones)
admin.site.register(Reviews)
